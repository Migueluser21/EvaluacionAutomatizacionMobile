package com.nttdata.stepsdefinitions;

import com.nttdata.steps.SwaglabsSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;

public class SwaglabsSD {

    @Steps
    SwaglabsSteps swaglabsSteps;

    @Given("que me enuentro en el login de Swaglabs")
    public void que_me_enuentro_en_el_login_de_Swaglabs() {
    }

    @When("inicio sesión con las credenciales usuario: {string} y contraseña: {string}")
    public void inicio_sesión_con_las_credenciales_usuario_y_contraseña(String user, String password) {
        swaglabsSteps.enterUser(user);
        swaglabsSteps.enterPass(password);
        swaglabsSteps.clickLogin();
    }

    @Then("valido que debería aparecer el título de {string}")
    public void valido_que_debería_aparecer_el_título_de(String expectedTitle) {
        Assert.assertEquals(expectedTitle, swaglabsSteps.getTituloPro());
    }

    @And("también valido que al menos exista un item")
    public void también_valido_que_al_menos_exista_un_item() {
        int itemsListSize = swaglabsSteps.getItemSize();
        Assert.assertTrue("El tamaño de la lista es: " + itemsListSize,itemsListSize > 0);
    }
}
