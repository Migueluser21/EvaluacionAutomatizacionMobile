package com.nttdata.steps;
import com.nttdata.screens.InventoryScreen;
import com.nttdata.screens.SwaglabsScreen;
import net.thucydides.core.annotations.Step;

public class SwaglabsSteps {
    SwaglabsScreen swaglabsScreen;

    InventoryScreen inventoryScreen;

    @Step("Ingresar usuario")
    public void enterUser(String user){
        swaglabsScreen.Ingresarusername(user);
    }

    @Step("Ingresar contraseña")
    public void enterPass(String password){
        swaglabsScreen.Ingresarpass(password);
    }

    @Step("Click en Login")
    public void clickLogin(){
        swaglabsScreen.clickLogin();
    }

    @Step("Obtiene el título de Productos")
    public String getTituloPro(){
        return inventoryScreen.getTituloPro();
    }

    @Step("Obtiene la cantidad de Items")
    public int getItemSize(){
        return inventoryScreen.getItemSize();
    }




}
