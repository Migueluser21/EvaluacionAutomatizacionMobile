package com.nttdata.screens;

import io.appium.java_client.pagefactory.AndroidFindBy;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;
public class SwaglabsScreen extends PageObject {
    @AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"test-Username\"]")
    private WebElement username;
    @AndroidFindBy(xpath="//android.widget.EditText[@content-desc=\"test-Password\"]")
    private WebElement pass;
    @AndroidFindBy(xpath="//android.view.ViewGroup[@content-desc=\"test-LOGIN\"]")
    private WebElement login;
    public void Ingresarusername(String user){

        username.sendKeys(user);
    }

    public void Ingresarpass(String password){

        pass.sendKeys(password);
    }

    public void clickLogin(){
        getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        login.click();
    }
}
